-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-12-2020 a las 20:54:49
-- Versión del servidor: 5.6.17
-- Versión de PHP: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `dbbioseguridad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE IF NOT EXISTS `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` enum('s','n') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`, `descripcion`, `estado`) VALUES
(1, 'Mascarillas', 'Mascarillas de todas las marcas ', 's'),
(2, 'LINEA ASEPSIA', 'SECTOR GOBIERNO LINEA ASEPSIA Y ANTISEPTICOS', 's'),
(3, 'LINEA FARMACEUTICA', 'ANTISEPTICOS, DESINFECTANTES Y GERMICIDAS', 's'),
(4, 'LINEA LAVADO Y ESTERIALIZACION', 'DETERGENTES, DESINFECTANTES Y BACTEORIOSTATICOS', 's'),
(5, 'LINEA MATERIAL BIOMEDICO', 'ALCOHOL PARA MANOS, CUTANEO Y GEL ANTIBACTERIAL', 's'),
(6, 'HORECA', 'HORECA', 's');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `documento` varchar(20) NOT NULL,
  `tipo_documento` enum('DNI','CARNET','RUC','OTROS') NOT NULL,
  `password` varchar(100) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `foto` text NOT NULL,
  `fech_nac` date NOT NULL,
  `fech_reg` date NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `direccion` text NOT NULL,
  `genero` enum('F','M','O') NOT NULL,
  `descuento` int(11) DEFAULT NULL,
  `estado` enum('s','n') NOT NULL,
  PRIMARY KEY (`documento`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`documento`, `tipo_documento`, `password`, `correo`, `nombre`, `apellido`, `foto`, `fech_nac`, `fech_reg`, `telefono`, `direccion`, `genero`, `descuento`, `estado`) VALUES
('1056895436', 'DNI', '1234', 'carlos@sistema.com', 'Simon', 'Castro Pardo', 'images/clientes/cliente.jpg', '2010-03-09', '2020-12-06', '974584458', 'calle sin numero jhgjhgjhg', 'M', 10, 's'),
('564645', 'DNI', '12345', 'kjhkjhj@jhjh.vom', 'hhhhhhhhh', 'llllllll', 'images/clientes/cliente.jpg', '2020-12-08', '2020-12-11', '546456', 'hkjlhjkhj', 'M', 0, 's'),
('788954', 'DNI', '123456', 'edgar@hotmail.com', 'Edgar', 'Gonzales', 'images/clientes/cliente.jpg', '2020-12-07', '2020-12-07', '985622458', 'Calle los pinos', 'M', 0, 's'),
('978548', 'DNI', '123456', 'adminkkk@web.com', 'adri', 'cast', 'images/clientes/cliente.jpg', '2020-12-11', '2020-12-11', '54645', 'jkhgjhgjhg', 'M', 0, 's');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE IF NOT EXISTS `compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_compra` date NOT NULL,
  `costo` float NOT NULL,
  `usuario` varchar(12) NOT NULL,
  `estado` enum('s','n') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `configurar`
--

CREATE TABLE IF NOT EXISTS `configurar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `IGV` int(11) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `configurar`
--

INSERT INTO `configurar` (`id`, `IGV`, `Nombre`) VALUES
(1, 18, 'Rocket sac');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `delivery`
--

CREATE TABLE IF NOT EXISTS `delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dias` varchar(14) NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `estado` enum('s','n') NOT NULL,
  `usuario` varchar(12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario` (`usuario`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `delivery`
--

INSERT INTO `delivery` (`id`, `dias`, `hora_inicio`, `hora_fin`, `estado`, `usuario`) VALUES
(1, '1/0/0/1/0/1/0', '08:00:00', '16:00:00', 's', '788885');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos`
--

CREATE TABLE IF NOT EXISTS `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `departamentos`
--

INSERT INTO `departamentos` (`id`, `nombre`, `estado`) VALUES
(1, 'Arequipa', 1),
(2, 'Ica', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_compras`
--

CREATE TABLE IF NOT EXISTS `detalle_compras` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cod_compra` int(11) NOT NULL,
  `producto` int(11) NOT NULL,
  `costo` float NOT NULL,
  `cantidad` int(11) NOT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `estado` enum('orden','almacen') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cod_compra` (`cod_compra`),
  KEY `producto` (`producto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_ventas`
--

CREATE TABLE IF NOT EXISTS `detalle_ventas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `venta` int(11) NOT NULL,
  `producto` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `servicio` int(11) DEFAULT NULL,
  `precio` float NOT NULL,
  `subtotal` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `producto` (`producto`),
  KEY `servicio` (`servicio`),
  KEY `venta` (`venta`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `detalle_ventas`
--

INSERT INTO `detalle_ventas` (`id`, `venta`, `producto`, `cantidad`, `servicio`, `precio`, `subtotal`) VALUES
(1, 1, 1, 10, NULL, 16, 160),
(2, 1, NULL, 1, 1, 200, 200),
(5, 8, 1, 1, NULL, 10, 10),
(6, 8, NULL, 1, 1, 200, 200),
(7, 9, 1, 2, NULL, 10, 20),
(8, 10, 16, 3, NULL, 188, 564),
(9, 10, 2, 1, NULL, 148, 148),
(10, 10, NULL, 1, 4, 400, 400),
(11, 11, 1, 2, NULL, 10, 20),
(12, 11, NULL, 1, 2, 250, 250);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `distritos`
--

CREATE TABLE IF NOT EXISTS `distritos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `provincia` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `provincia` (`provincia`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `distritos`
--

INSERT INTO `distritos` (`id`, `nombre`, `provincia`, `estado`) VALUES
(1, 'Paucarpata', 1, 1),
(2, 'Miraflores', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `privilegios`
--

CREATE TABLE IF NOT EXISTS `privilegios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(20) NOT NULL,
  `permisos` varchar(255) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `privilegios`
--

INSERT INTO `privilegios` (`id`, `nombre`, `permisos`, `estado`) VALUES
(1, 'Administrador', '1/1/1/1/1/1/1/1/1/1', 1),
(2, 'Auxiliar', '0/0/0/0/1/1/1/1/0/0', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE IF NOT EXISTS `productos` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `costo` float NOT NULL,
  `precio` float NOT NULL,
  `detalle` text NOT NULL,
  `marca` varchar(100) NOT NULL,
  `foto` text NOT NULL,
  `medida` enum('caja','unidad','pakete') NOT NULL,
  `stock` int(11) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `proveedor` varchar(12) NOT NULL,
  `categoria` int(11) NOT NULL,
  `estado` enum('s','n') NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `categoria` (`categoria`),
  KEY `proveedor` (`proveedor`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`codigo`, `nombre`, `costo`, `precio`, `detalle`, `marca`, `foto`, `medida`, `stock`, `fecha_ingreso`, `proveedor`, `categoria`, `estado`) VALUES
(1, 'F103', 8, 10, 'Una barra de nariz de aluminio suave ajustable permite un fácil moldeado en la nariz y un ajuste óptimo\r\nBanda para la oreja 100% libre de látex que evita la irritación y elimina la presión en la oreja\r\nHipoalergénico debido al material sintético de polipropileno que previene las alergias.\r\nSin fibra de vidrio\r\nLa unión ultrasónica automática se suma a la limpieza de la máscara.\r\nLigero y cómodo de usar en ambientes húmedos\r\nUna construcción de triple capa de 3 pliegues proporciona un soporte más fuerte a la máscara.\r\nContiene 10 unidades', 'Dromex', 'https://www.dromex.co.za/wp-content/uploads/2019/04/3plyfacemask-600x600.jpg', 'caja', 48, '2020-12-12', '10458754854', 1, 's'),
(2, 'IDO SAFE ESPUMA 8.5%', 145, 148, 'IDOSAFE – ESPUMA MICROBICIDA SOLUCIÓN – YODO POLIVIDONA AL 8.5%\r\nAntiséptico y desinfectante solo para uso externo, útil en la limpieza y desinfección de la piel, heridas, quemaduras leves, infecciones como acné vulgaris de cara y cuello, seborrea y caspa del cuero cabelludo, tratamiento de micosis, herpes, desinfección rutinaria de manos antes del contacto quirúrgico, lavado y limpieza de áreas quirúrgicas.', 'ROKER', 'https://i2.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/familia-idosafe85.jpg?resize=768%2C619&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(3, 'ANTISEPTICO CUTANEO', 145, 148, 'Se indica sobretodo para el uso en clínicas, industrias de alimentos, y lugares donde la asepsia de manos\r\n\r\nes de importancia fundamental para mantener buenas condiciones de higiene y salud.', 'ROKER', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/1-4.jpg?resize=768%2C960&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(4, 'Jabón líquido', 145, 148, 'HIBICLEN 4% ANTISEPTICO CUTANEO\r\nAntiséptico Cutáneo, desarrollado a base de Gluconato de Clorhexidina al 4%, con principios \r\nactivos de amplio espectro antimicrobiano.\r\n\r\nFormulado en una mezcla de humectantes, emolientes y aloe vera; lo que no sólo permite un lavado y protección posterior\r\n para el proceso quirúrgico, sino que impide el deterioro de la piel, gracias a la acción de sus sustancias protectoras y regeneradoras.\r\n\r\nAdicionalmente está indicado\r\n para la desinfección pre-operatoria de la piel del paciente.\r\n\r\nPRESENTACIONES\r\n1 Litro\r\n1 Litro Circuito Cerrado (incluye bombilla translúcida, sistema de filtros,\r\n y sujetador de pared)\r\n1 Galón', 'ROKER', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/familia-hibiclen4.jpg?resize=526%2C424', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(5, 'SUPERSAFE – D', 145, 148, 'Limpieza y Desinfección de los dispositivos médicos y de las superficies horizontales: mesas, encimeras. Pulverizado en Áreas extensas otorga una desinfección adecuada de Cuartos de Hospitalización, Tópicos de Emergencia, Salas de Operaciones, etc. Bactericida en condiciones de suciedad. No corrosivo.', 'HIBICLEN', 'https://i0.wp.com/roker.com.pe/web/wp-content/uploads/2016/05/supersafe_d_solo_1.jpg?resize=551%2C1024&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(6, 'ALCOHOL FOAM', 145, 148, 'HIBICLEN 4% ANTISEPTICO CUTANEO\r\nAntiséptico Cutáneo, desarrollado a base de Gluconato de Clorhexidina al 4%, con principios \r\nactivos de amplio espectro antimicrobiano.\r\n\r\nFormulado en una mezcla de humectantes, emolientes y aloe vera; lo que no sólo permite un lavado y protección posterior\r\n para el proceso quirúrgico, sino que impide el deterioro de la piel, gracias a la acción de sus sustancias protectoras y regeneradoras.\r\n\r\nAdicionalmente está indicado\r\n para la desinfección pre-operatoria de la piel del paciente.\r\n\r\nPRESENTACIONES\r\n1 Litro\r\n1 Litro Circuito Cerrado (incluye bombilla translúcida, sistema de filtros,\r\n y sujetador de pared)\r\n1 Galón', 'ROKER', 'https://i2.wp.com/roker.com.pe/web/wp-content/uploads/2016/05/alcohol-foam-solo.jpg?resize=750%2C1024&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(7, 'HIBICLEN AV ESPUMA 2%', 145, 148, 'DESARROLLADO A BASE DE GLUCONATO DE CLORHEXIDINA AL 2%, FORMULADO EN UNA MEZCLA DE HUMECTANTES, EMOLIENTES Y ALOE VERA; LO QUE NO SÓLO PERMITE UN LAVADO Y PROTECCIÓN POSTERIOR PARA EL PROCESO DE LAVADO CLÍNICO, SINO QUE IMPIDE EL DETERIORO EN LA PIEL GRACIAS A LA ACCIÓN DE SUS SUSTANCIAS PROTECTORAS Y REGENERADORAS DE LA PIEL.', 'HIBICLEN', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/familia-hibiclen2.jpg?resize=768%2C619&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(8, 'HIBIGEL 6H', 145, 148, 'Antiséptico instantáneo de amplio espectro, utilizado para la asepsia de las manos del Personal Médico, Enfermeras, Paramédicos y otros profesionales de la salud, así como de uso general.\r\n\r\nHibigel es de fácil aplicación y no necesita enjuague. En su formulación contiene humectantes, emolientes y regeneradores de la piel (aloe vera), que le brindará a sus manos doble beneficio: asepsia y suavidad.', 'HIBICLEN', 'https://i0.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/familia-hibigel.jpg?resize=768%2C634&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(9, 'CLORURO DE BENZALCONIO AL 5%', 145, 148, 'Antiséptico de amplio espectro, es un jabón muy efectivo en pequeñas cantidades para la limpieza y la desinfección de las manos con sustancias tensoactivas regeneradoras de la piel.\r\n\r\nIdeal para la desinfección de superficies de paredes, pisos, mayólicas, etc.\r\n\r\nEn la desinfección de ropa por inversión: reduce el porcentaje de dermatitis en los recién nacidos.', 'HIBICLEN', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2017/12/post-safegreen.jpg?resize=238%2C300&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(10, 'Jabón en base líquida sin antisepticos.', 145, 148, 'Recomendado para la limpieza de manos y demas partes del cuerpo. Contiene humectantes que ayudan a reducir las irritaciones de la piel.', 'HIBICLEN', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/05/visan_solo.jpg?resize=560%2C1024&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 2, 's'),
(11, 'ALCOHOL FOAM', 145, 188, 'Antiséptico y desinfectante solo para uso externo, útil en la limpieza y desinfección de la piel, heridas, quemaduras leves, infecciones como acné vulgaris de cara \r\ny cuello, seborrea y caspa del cuero cabelludo, tratamiento de micosis, herpes, desinfección rutinaria de manos antes del contacto quirúrgico, lavado y limpieza \r\nde áreas quirúrgicas.', 'ROKER', 'https://i0.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/idosafe75solo2.jpg?resize=750%2C1024&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 3, 's'),
(12, 'SILVADINA', 145, 188, 'Está indicado como agente primario en el tratamiento y profilaxis tópica, de infecciones de heridas de quemaduras por cándida albicans (monilla albicans), especies de citrobacter, especies de enterobacter (incluida E. Cloacae), enterococos, E. Coly, especies de klebsiela, proteus mirabilis, proteus vulgaris, pseudomona aeroginosa, especies de serratia, staphylococcus aureus, streptococcus beta hemolítico, en pacientes con quemaduras de segundo y tercer grado, en el tratamiento de infecciones bacterianas de la piel o úlceras dérmicas, en el tratamiento tópico de infecciones de piel, en complicaciones que se producen en injertos de piel, incisiones, abrasiones y úlceras dermales.', 'ROKER', 'https://i2.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/silvadina.jpg?resize=768%2C357&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 3, 's'),
(13, 'SAFE BLON H', 145, 188, 'ANTISÉPTICO SÓLO PARA USO EXTERNO, INDICADO EN LA DESINFECCIÓN DE INSTRUMENTOS, LIMPIEZA Y ASEPSIA DE PIEL Y/O HERIDAS POST-OPERATORIAS, OBSTÉTRICAS, GINECOLÓGICAS Y UROLÓGICAS.', 'ROKER', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/safeblon_h_solo.jpg?resize=750%2C1024&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 3, 's'),
(14, 'MUPIROCINA', 145, 188, 'Impétigo: Se indica, solo un agente primario, en el tratamiento tópico de impétigo localizado causado por el Staphylococcus aureus y el estreptococo beta-hemolitico, incluyendo el Streptococcus pyogenes.', 'ROKER', 'https://i2.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/cremamupirocina.jpg?w=631&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 3, 's'),
(15, 'IDO SAFE SOLUCION 10%', 145, 188, 'Antiséptico y desinfectante germicida, sólo para uso externo, indicado en la limpieza y desinfección de la piel, heridas, quemaduras leves, seborrea y caspa del cuero cabelludo, tratamiento de micosis y limpieza de áreas quirúrgicas.', 'ROKER', 'https://i2.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/idosafe10solo.jpg?resize=750%2C1024&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 3, 's'),
(16, 'SULFAKIDS', 145, 188, 'Crema tópica: Indicado en el tratamiento de:\r\n\r\n– Infecciones en quemaduras (profilaxis y tratamiento) producidas por organismos sensibles a la Sulfadiazina de Plata.', 'ROKER', 'https://i2.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/sulfakids.jpg?w=732&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 3, 's'),
(17, 'DOLORCREM', 145, 188, 'DOLORCREM CREMA está indicado en el control de la inflamación y alivio del dolor en los casos de lesiones deportivas, contusiones, torceduras, bursitis, tendinitis epicondilitis, sinovitis, osteoartritis, artritis, reumática, artrosis.\r\n\r\nEn medicina de rehabilitación puede usarse previa a la terapia Kinésica para favorecer la vilización de las estructuras afectadas.', 'ROKER', 'https://i2.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/dolorcrem.jpg?w=732&ssl=1', 'unidad', 3, '2020-12-03', '10458754854', 3, 's'),
(18, 'DETERZIMATIC', 145, 188, 'Es un detergente enzimático bactericida en polvo, de acción descontaminante de alto rendimiento, con grandes propiedades de limpieza y descontaminación de grasas, proteínas, almidones-carbohidratos. Su función es acelerar la descomposición de restos de materia organica provenientes de sangre, heces y grasas. Producto Aséptico.', 'ROKER', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/unnamed.jpg?resize=150%2C180', 'unidad', 3, '2020-12-03', '10458754854', 3, 's'),
(19, 'MULTIZIM P', 145, 188, 'Detergente Proteolítico Enzimático reforzado de cuatro enzimas (Amilasa, Lipasa, Proteasa y Carbohidrasa), de acción bacteriostática de \r\nalto rendimiento con grandes propiedades de limpieza y degradación de grasas, proteínas, almidones, carbohidratos.', 'ROKER', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/multizim_p_solo.jpg?resize=750%2C1024&ssl=1', 'unidad', 4, '2020-12-03', '10458754854', 3, 's'),
(20, 'MICROBIEX', 145, 188, 'Desinfectante usualmente empleado en el medio hospitalario debido a que tiene un amplio espectro de acción, BACTERICIDA, FUNGICIDA, VIRUCIDA, TUBERCULICIDA, PSEUDOMONICIDA. Es activo en presencia de materia orgánica y no es corrosivo. Dependiendo del tiempo de acción se alcanza distintos grados de desinfección: Esterilización, Desinfección de Alto Nivel y Desinfección en General.', 'ROKER', 'https://i2.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/microbiex_solo.jpg?resize=750%2C1024&ssl=1', 'unidad', 4, '2020-12-03', '10458754854', 3, 's'),
(21, 'BIO ZIM', 145, 188, 'Producto elaborado a base de enzimas, proteasas, amilasas y lipasas que se sinergizan para un mejor desprendimiento, por lo que disuelven y eliminan cualquier contaminante orgánico como: sangre seca o suciedad protéica, grasa, orina o manchas en ropa, material quirúrgico, en endoscopios de fibra óptica flexible, pinzas para biopsia; eliminando olores biológicos y tienen además la ventaja de ser completamente biodegradables. Desinfectante de material médico quirúrgico.', 'ROKER', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/biozim-15-1.jpg?resize=768%2C836&ssl=1', 'unidad', 4, '2020-12-03', '10458754854', 3, 's'),
(22, 'AQUACIDE', 145, 188, 'Solución desinfectante y esterilizante para instrumental termosensible tales como: Endoscopios, Fibroscopios, Instrumental y Equipo óptico, quirúrgico y dental.', 'ROKER', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/aquacidel-solo.jpg?resize=750%2C1024&ssl=1', 'unidad', 4, '2020-12-03', '10458754854', 3, 's'),
(23, 'DETERZIMATIC\r\n', 145, 188, 'Es un detergente enzimático bactericida en polvo, de acción descontaminante de alto rendimiento, con grandes propiedades de limpieza y descontaminación de grasas, proteínas, almidones-carbohidratos. Su función es acelerar la descomposición de restos de materia organica provenientes de sangre, heces y grasas. Producto Aséptico.', 'ROKER', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/unnamed.jpg?resize=150%2C180', 'unidad', 4, '2020-12-03', '10458754854', 3, 's'),
(24, 'ANTISEPTICO CUTANEO', 145, 148, 'HIBICLEN 4% ANTISEPTICO CUTANEO\r\nAntiséptico Cutáneo, desarrollado a base de Gluconato de Clorhexidina al 4%, con principios activos de amplio espectro antimicrobiano.\r\n\r\nFormulado en una mezcla de humectantes, emolientes y aloe vera; lo que no sólo permite un lavado y protección posterior para el proceso quirúrgico, sino que impide el deterioro de la piel, gracias a la acción de sus sustancias protectoras y regeneradoras.\r\n\r\nAdicionalmente está indicado para la desinfección pre-operatoria de la piel del paciente.\r\n\r\nPRESENTACIONES\r\n1 Litro\r\n1 Litro Circuito Cerrado (incluye bombilla translúcida, sistema de filtros, y sujetador de pared)\r\n1 Galón', 'HIBICLEN', 'https://i1.wp.com/roker.com.pe/web/wp-content/uploads/2016/04/familia-hibiclen4.jpg?resize=526%2C424', 'unidad', 3, '2020-12-03', '10458754854', 2, 's');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE IF NOT EXISTS `proveedores` (
  `documento` varchar(12) NOT NULL,
  `tipo_doc` enum('DNI','RUC','CARNET') NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `dieccion` text NOT NULL,
  `calificacion` int(11) NOT NULL,
  `estado` enum('s','n') NOT NULL,
  PRIMARY KEY (`documento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`documento`, `tipo_doc`, `nombre`, `telefono`, `correo`, `dieccion`, `calificacion`, `estado`) VALUES
('10458754854', 'RUC', 'Importador copsa', '98556854', 'ventas@copsa.com', 'Av Mexico  cuadra 4 La Victoria Lima', 1, 's');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincias`
--

CREATE TABLE IF NOT EXISTS `provincias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `departamento` int(11) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `departamento` (`departamento`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcado de datos para la tabla `provincias`
--

INSERT INTO `provincias` (`id`, `nombre`, `departamento`, `estado`) VALUES
(1, 'Arequipa', 1, 1),
(2, 'Castilla', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicios`
--

CREATE TABLE IF NOT EXISTS `servicios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `detalle` text NOT NULL,
  `costo` float NOT NULL,
  `foto` text NOT NULL,
  `estado` enum('s','n') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Volcado de datos para la tabla `servicios`
--

INSERT INTO `servicios` (`id`, `nombre`, `detalle`, `costo`, `foto`, `estado`) VALUES
(1, 'Asesores Prevención Riesgos Laborales IKA', 'Las empresas deben colaborar con la formación sobre COVID-19, y la información sobre exposición al coronavirus.\r\nDeben hacer la evaluación de riesgos laborales.\r\nTe abrimos nuestras aulas de formación online para tu empresa y tus empleados para que no tengas dudas.\r\nTenemos una variedad de ofertas formativas.\r\n\r\nConsulta nuestros cursos y seminarios en materia de ', 200, 'https://arcocovid.com/wp-content/uploads/2020/05/cleaning-services-09.jpg', 's'),
(2, 'CAPACITACIONES EN SEGURIDAD Y SALUD EN EL TRABAJO', 'GENERAMOS COMPETENCIAS A TRAVÉS DEL CONOCIMIENTO.\r\n\r\nGESTIONAMOS EL CONOCIMIENTO, POTENCIAMOS HABILIDADES.\r\n\r\n INVERTIR EN CONOCIMIENTO PRODUCE SIEMPRE LOS MEJORES BENEFICIOS.\r\n\r\nCapacitaciones presenciales(In House y en nuestras salas)\r\nCapacitaciones a distancia (Virtual y OnLine)', 250, 'https://img1.wsimg.com/isteam/stock/Y8kdoa7/:/cr=t:7.63%25,l:0%25,w:100%25,h:84.75%25/rs=w:388,h:194,cg:true', 's'),
(3, 'MONITOREOS OCUPACIONALES', 'Realizamos los distintos tipos de monitoreos\r\n\r\nRiesgo químico\r\nRiesgo biológico\r\nRiego físico\r\nRiesgo psicosocial\r\nRiesgo disergonómico, etc.\r\nDe acuerdo a la evaluación de riesgos establecidos en su sistema de gestión de seguridad y salud en el trabajo.', 350, 'https://img1.wsimg.com/isteam/ip/6d0d1a1b-cfac-40ce-9129-d510ef310a50/IMG_20191022_101719.jpg/:/cr=t:44.95%25,l:0%25,w:100%25,h:37.49%25/rs=w:388,h:194,cg:true', 's'),
(4, 'SISTEMAS DE GESTIÓN DE SEGURIDAD Y SALUD EN EL TRABAJO', 'Su sistema de gestión de seguridad y salud en el trabajo, debe ayudarle a gestionar los riesgos.\r\n\r\nLo implementamos.\r\n\r\nSi ya lo tiene, lo mejoramos y los potenciamos.\r\n\r\nLa documentación del SGSST, debe contener:\r\n\r\n-La política y objetivos en materia de SST.', 400, 'https://img1.wsimg.com/isteam/stock/y6Erjz0/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(5, 'HOMOLOGACIONES EN SEGURIDAD Y SALUD EN EL TRABAJO', 'Sus clientes, necesitan estar seguros que su empresa, cumple con la ley, es decir, tener un Sistema de Gestión de Seguridad y Salud en el Trabajo eficiente, eficaz y debidamente implementado.\r\n\r\nLo ayudamos a calificar como proveedor homologado, lo asesoramos en la preparación de requisitos, presentación de documentos y homologación.', 550, 'https://img1.wsimg.com/isteam/stock/V5Kw8mW/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(6, 'SIMULACROS Y ENTRENAMIENTOS', 'Entrenamos a sus brigadas en primeros auxilios, evacuación y rescate, control de amago de incendios.\r\n\r\nPreparamos a las brigadas través de los simulacros.', 0, 'https://img1.wsimg.com/isteam/stock/79283/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(7, 'AUDITORIAS DE SEGURIDAD Y SALUD EN EL TRABAJO', 'Realizamos auditorias exigidas por el ministerio de trabajo, todas las empresas deben realizar auditorias obligatorias por lo menos una vez al año de su sistema de gestión de seguridad y salud en el trabajo y de acuerdo al tipo de actividad que realizan.', 550, 'https://img1.wsimg.com/isteam/stock/QB6V1ma/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(8, 'PLAN Y PROTOCOLO PARA LA VIGILANCIA, PREVENCIÓN Y CONTROL COVID-19 EN EL TRABAJO', 'Elaboramos su Plan y protocolo de vigilancia, la exposición al virus SARS-CoV2, produce la enfermedad COVID-19, representa un riesgo biológico, de ALTA TRANSMISIBILIDAD, a través de EnviroCHem te ayudamos a: Establecer los lineamientos para la vigilancia, prevención y control de la salud de los trabajadores con riesgo a exposición a SARS-CoV2, estas incluyen:\r\n\r\n-Las actividades que se realizan durante al pandemia.\r\n\r\n-Regreso y reincorporación al trabajo, etc.', 300, 'https://img1.wsimg.com/isteam/stock/Zzzbgej/:/cr=t:23.08%25,l:0%25,w:100%25,h:76.92%25/rs=w:388,h:194,cg:true', 's'),
(9, 'VIGILANCIA DE LA SALUD DEL TRABAJADOR EN EL CONTEXTO COVID-19', 'A través de nuestros médicos ocupacionales, realizamos la vigilancia de la salud de los trabajadores y sus respectivos controles.', 199, 'https://img1.wsimg.com/isteam/stock/6yEz9rq/:/rs=w:582,h:291,cg:true,m/cr=w:582,h:291', 's'),
(10, 'CAPACITACIONES EN SEGURIDAD Y SALUD EN EL TRABAJO', 'GENERAMOS COMPETENCIAS A TRAVÉS DEL CONOCIMIENTO.\r\n\r\nGESTIONAMOS EL CONOCIMIENTO, POTENCIAMOS HABILIDADES.\r\n\r\n INVERTIR EN CONOCIMIENTO PRODUCE SIEMPRE LOS MEJORES BENEFICIOS.\r\n\r\nCapacitaciones presenciales(In House y en nuestras salas)\r\nCapacitaciones a distancia (Virtual y OnLine)', 250, 'https://img1.wsimg.com/isteam/stock/Y8kdoa7/:/cr=t:7.63%25,l:0%25,w:100%25,h:84.75%25/rs=w:388,h:194,cg:true', 's'),
(11, 'MONITOREOS OCUPACIONALES', 'Realizamos los distintos tipos de monitoreos\r\n\r\nRiesgo químico\r\nRiesgo biológico\r\nRiego físico\r\nRiesgo psicosocial\r\nRiesgo disergonómico, etc.\r\nDe acuerdo a la evaluación de riesgos establecidos en su sistema de gestión de seguridad y salud en el trabajo.', 350, 'https://img1.wsimg.com/isteam/ip/6d0d1a1b-cfac-40ce-9129-d510ef310a50/IMG_20191022_101719.jpg/:/cr=t:44.95%25,l:0%25,w:100%25,h:37.49%25/rs=w:388,h:194,cg:true', 's'),
(12, 'SISTEMAS DE GESTIÓN DE SEGURIDAD Y SALUD EN EL TRABAJO', 'Su sistema de gestión de seguridad y salud en el trabajo, debe ayudarle a gestionar los riesgos.\r\n\r\nLo implementamos.\r\n\r\nSi ya lo tiene, lo mejoramos y los potenciamos.\r\n\r\nLa documentación del SGSST, debe contener:\r\n\r\n-La política y objetivos en materia de SST.', 400, 'https://img1.wsimg.com/isteam/stock/y6Erjz0/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(13, 'HOMOLOGACIONES EN SEGURIDAD Y SALUD EN EL TRABAJO', 'Sus clientes, necesitan estar seguros que su empresa, cumple con la ley, es decir, tener un Sistema de Gestión de Seguridad y Salud en el Trabajo eficiente, eficaz y debidamente implementado.\r\n\r\nLo ayudamos a calificar como proveedor homologado, lo asesoramos en la preparación de requisitos, presentación de documentos y homologación.', 550, 'https://img1.wsimg.com/isteam/stock/V5Kw8mW/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(14, 'SIMULACROS Y ENTRENAMIENTOS', 'Entrenamos a sus brigadas en primeros auxilios, evacuación y rescate, control de amago de incendios.\r\n\r\nPreparamos a las brigadas través de los simulacros.', 0, 'https://img1.wsimg.com/isteam/stock/79283/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(15, 'AUDITORIAS DE SEGURIDAD Y SALUD EN EL TRABAJO', 'Realizamos auditorias exigidas por el ministerio de trabajo, todas las empresas deben realizar auditorias obligatorias por lo menos una vez al año de su sistema de gestión de seguridad y salud en el trabajo y de acuerdo al tipo de actividad que realizan.', 550, 'https://img1.wsimg.com/isteam/stock/QB6V1ma/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(16, 'PLAN Y PROTOCOLO PARA LA VIGILANCIA, PREVENCIÓN Y CONTROL COVID-19 EN EL TRABAJO', 'Elaboramos su Plan y protocolo de vigilancia, la exposición al virus SARS-CoV2, produce la enfermedad COVID-19, representa un riesgo biológico, de ALTA TRANSMISIBILIDAD, a través de EnviroCHem te ayudamos a: Establecer los lineamientos para la vigilancia, prevención y control de la salud de los trabajadores con riesgo a exposición a SARS-CoV2, estas incluyen:\r\n\r\n-Las actividades que se realizan durante al pandemia.\r\n\r\n-Regreso y reincorporación al trabajo, etc.', 300, 'https://img1.wsimg.com/isteam/stock/Zzzbgej/:/cr=t:23.08%25,l:0%25,w:100%25,h:76.92%25/rs=w:388,h:194,cg:true', 's'),
(17, 'VIGILANCIA DE LA SALUD DEL TRABAJADOR EN EL CONTEXTO COVID-19', 'A través de nuestros médicos ocupacionales, realizamos la vigilancia de la salud de los trabajadores y sus respectivos controles.', 199, 'https://img1.wsimg.com/isteam/stock/6yEz9rq/:/rs=w:582,h:291,cg:true,m/cr=w:582,h:291', 's'),
(18, 'ASESORÍA Y CONSULTORÍA EN SEGURIDAD Y SALUD EN EL TRABAJO', 'Servicio personalizado en materias de:\r\n\r\nSeguridad y prevención laboral\r\n\r\nSalud ocupacional\r\n\r\nGestión ambiental', 500, 'https://img1.wsimg.com/isteam/stock/4527/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(19, 'SALUD OCUPACIONAL', 'Te asesoramos permanente, a través de nuestros médicos ocupacionales colegiados\r\n\r\nRealizamos la implementación y vigilancia médica de la salud del trabajador.\r\n\r\nRealizamos la evaluación de riesgo psicosocial, evaluación de riesgo disergonómico y el entrenamiento a la brigada de primeros auxilios.', 380, 'https://img1.wsimg.com/isteam/stock/pmeQ9Ww/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(20, 'IMPLEMENTACIÓN DE LA PREVENCIÓN Y SANCIÓN DEL HOSTIGAMIENTO SEXUAL', 'Las empresas deben implementar, a través del D.S. 014-2019 MIMP, y la Ley 29742 lo siguiente:\r\n\r\nElección de un delegado contra el hostigamiento sexual.\r\n\r\nEvaluar y realizar el diagnostico anual del hostigamiento sexual\r\n\r\nConformación y capacitación de un comité interno\r\n\r\nPolíticas internas para la prevención y sanción del hostigamiento sexual.\r\n\r\nProcedimiento interno de investigación y sanción.\r\n\r\nCapacitaciones anuales de sensibilización.', 398, 'https://img1.wsimg.com/isteam/ip/6d0d1a1b-cfac-40ce-9129-d510ef310a50/Hostigamiento%20sexual%20laboral.jpg/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(21, 'PLAN DE SALUD MENTAL', 'Elaboramos:\r\n\r\n-Programas que incluyan medidas de detención y protección ante el estrés laboral, acoso, hostigamiento sexual, malestar, desmotivación desconfianza, agotamiento laboral, violencia institucional.\r\n\r\n-Programas de nutrición y actividad física.\r\n\r\nManuales\r\n\r\nSu incumplimiento, podrá resultar en sanciones, administrativas, civiles y penales, dependiendo del grado de afectación al trabajador', 980, 'https://img1.wsimg.com/isteam/stock/wVR9kmY/:/cr=t:0%25,l:0%25,w:100%25,h:84.16%25/rs=w:582,h:291,cg:true', ''),
(22, 'ASESORÍA Y CONSULTORÍA EN SEGURIDAD Y SALUD EN EL TRABAJO', 'Servicio personalizado en materias de:\r\n\r\nSeguridad y prevención laboral\r\n\r\nSalud ocupacional\r\n\r\nGestión ambiental', 500, 'https://img1.wsimg.com/isteam/stock/4527/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(23, 'SALUD OCUPACIONAL', 'Te asesoramos permanente, a través de nuestros médicos ocupacionales colegiados\r\n\r\nRealizamos la implementación y vigilancia médica de la salud del trabajador.\r\n\r\nRealizamos la evaluación de riesgo psicosocial, evaluación de riesgo disergonómico y el entrenamiento a la brigada de primeros auxilios.', 380, 'https://img1.wsimg.com/isteam/stock/pmeQ9Ww/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(24, 'IMPLEMENTACIÓN DE LA PREVENCIÓN Y SANCIÓN DEL HOSTIGAMIENTO SEXUAL', 'Las empresas deben implementar, a través del D.S. 014-2019 MIMP, y la Ley 29742 lo siguiente:\r\n\r\nElección de un delegado contra el hostigamiento sexual.\r\n\r\nEvaluar y realizar el diagnostico anual del hostigamiento sexual\r\n\r\nConformación y capacitación de un comité interno\r\n\r\nPolíticas internas para la prevención y sanción del hostigamiento sexual.\r\n\r\nProcedimiento interno de investigación y sanción.\r\n\r\nCapacitaciones anuales de sensibilización.', 398, 'https://img1.wsimg.com/isteam/ip/6d0d1a1b-cfac-40ce-9129-d510ef310a50/Hostigamiento%20sexual%20laboral.jpg/:/rs=w:388,h:194,cg:true,m/cr=w:388,h:194', 's'),
(25, 'PLAN DE SALUD MENTAL', 'Elaboramos:\r\n\r\n-Programas que incluyan medidas de detención y protección ante el estrés laboral, acoso, hostigamiento sexual, malestar, desmotivación desconfianza, agotamiento laboral, violencia institucional.\r\n\r\n-Programas de nutrición y actividad física.\r\n\r\nManuales\r\n\r\nSu incumplimiento, podrá resultar en sanciones, administrativas, civiles y penales, dependiendo del grado de afectación al trabajador', 980, 'https://img1.wsimg.com/isteam/stock/wVR9kmY/:/cr=t:0%25,l:0%25,w:100%25,h:84.16%25/rs=w:582,h:291,cg:true', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `documento` varchar(12) NOT NULL,
  `tipo_doc` enum('DNI','Carnet') NOT NULL,
  `password` varchar(100) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `fech_na` date NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `genero` enum('M','F') NOT NULL,
  `foto` text NOT NULL,
  `privilegio` int(11) NOT NULL,
  `estado` enum('s','n') NOT NULL,
  PRIMARY KEY (`documento`),
  UNIQUE KEY `usuario` (`correo`),
  KEY `privilegio` (`privilegio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`documento`, `tipo_doc`, `password`, `correo`, `nombre`, `apellido`, `fech_na`, `telefono`, `direccion`, `fecha_ingreso`, `genero`, `foto`, `privilegio`, `estado`) VALUES
('788885', 'DNI', '123456', 'admin@web.com', 'Fernando', 'Castro', '2000-12-07', '48785695', 'calle pilar', '2020-12-07', 'M', 'images/personal/persona.jpg', 1, 's');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE IF NOT EXISTS `ventas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_venta` datetime DEFAULT NULL,
  `fecha_pedido` datetime NOT NULL,
  `subtotal` float NOT NULL,
  `descuento` float NOT NULL,
  `IGV` float NOT NULL,
  `total` float NOT NULL,
  `cliente` varchar(20) DEFAULT NULL,
  `delivery` int(11) DEFAULT NULL,
  `estado` enum('pedido','entrega','vendido','retorno') NOT NULL,
  `vendedor` varchar(12) DEFAULT NULL,
  `numero_pago` varchar(20) DEFAULT NULL,
  `direccion` text,
  `distrito` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vendedor` (`vendedor`),
  KEY `delivery` (`delivery`),
  KEY `cliente` (`cliente`),
  KEY `distrito` (`distrito`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `fecha_venta`, `fecha_pedido`, `subtotal`, `descuento`, `IGV`, `total`, `cliente`, `delivery`, `estado`, `vendedor`, `numero_pago`, `direccion`, `distrito`) VALUES
(1, '2020-12-13 00:00:00', '2020-12-14 00:00:00', 164, 0, 36, 200, '564645', 1, 'pedido', '788885', '456546', 'calle los incas 456', 2),
(2, NULL, '2020-12-13 21:28:29', 210, 0, 34.02, 189, '1056895436', 1, 'pedido', NULL, '8886', 'calle sin numero jhgjhgjhg', 1),
(3, NULL, '2020-12-13 21:37:51', 210, 21, 34.02, 189, '1056895436', 1, 'pedido', NULL, '7519', 'calle sin numero jhgjhgjhg', 1),
(4, NULL, '2020-12-13 21:46:09', 210, 21, 34.02, 189, '1056895436', 1, 'pedido', NULL, '7519', 'calle sin numero jhgjhgjhg', 2),
(5, NULL, '2020-12-13 21:49:38', 210, 21, 34.02, 189, '1056895436', 1, 'pedido', NULL, '7519', 'calle sin numero jhgjhgjhg', 2),
(6, NULL, '2020-12-13 22:10:30', 210, 21, 34.02, 189, '1056895436', 1, 'pedido', NULL, '7306', 'calle sin numero jhgjhgjhg', 1),
(7, NULL, '2020-12-13 22:12:29', 210, 21, 34.02, 189, '1056895436', 1, 'pedido', NULL, '7306', 'calle sin numero jhgjhgjhg', 1),
(8, NULL, '2020-12-13 22:32:49', 210, 21, 34.02, 189, '1056895436', 1, 'entrega', '788885', '7963', 'calle sin numero jhgjhgjhg', 2),
(9, NULL, '2020-12-13 22:52:20', 20, 2, 3.24, 18, '1056895436', 1, 'entrega', '788885', '1354', 'calle sin numero jhgjhgjhg', 1),
(10, NULL, '2020-12-14 08:15:47', 1112, 111.2, 180.144, 1000.8, '1056895436', 1, 'entrega', '788885', '7787', 'calle sin numero jhgjhgjhg', 1),
(11, NULL, '2020-12-14 09:30:57', 270, 27, 43.74, 243, '1056895436', 1, 'entrega', '788885', '6161', 'calle sin numero jhgjhgjhg', 1);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `fk_compra_usu` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`documento`);

--
-- Filtros para la tabla `delivery`
--
ALTER TABLE `delivery`
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`documento`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `detalle_compras`
--
ALTER TABLE `detalle_compras`
  ADD CONSTRAINT `fk_detalle_prodc` FOREIGN KEY (`producto`) REFERENCES `productos` (`codigo`),
  ADD CONSTRAINT `fk_detalle_compra` FOREIGN KEY (`cod_compra`) REFERENCES `compra` (`id`);

--
-- Filtros para la tabla `detalle_ventas`
--
ALTER TABLE `detalle_ventas`
  ADD CONSTRAINT `fk_producto_vt` FOREIGN KEY (`producto`) REFERENCES `productos` (`codigo`),
  ADD CONSTRAINT `fk_servicio` FOREIGN KEY (`servicio`) REFERENCES `servicios` (`id`),
  ADD CONSTRAINT `fk_ventas` FOREIGN KEY (`venta`) REFERENCES `ventas` (`id`);

--
-- Filtros para la tabla `distritos`
--
ALTER TABLE `distritos`
  ADD CONSTRAINT `fx_provincia` FOREIGN KEY (`provincia`) REFERENCES `provincias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_categoria` FOREIGN KEY (`categoria`) REFERENCES `categorias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_proveedor` FOREIGN KEY (`proveedor`) REFERENCES `proveedores` (`documento`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `provincias`
--
ALTER TABLE `provincias`
  ADD CONSTRAINT `fk_departamento` FOREIGN KEY (`departamento`) REFERENCES `departamentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_privilegio` FOREIGN KEY (`privilegio`) REFERENCES `privilegios` (`id`);

--
-- Filtros para la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`cliente`) REFERENCES `clientes` (`documento`),
  ADD CONSTRAINT `fk_delivery` FOREIGN KEY (`delivery`) REFERENCES `delivery` (`id`),
  ADD CONSTRAINT `fk_distrito` FOREIGN KEY (`distrito`) REFERENCES `distritos` (`id`),
  ADD CONSTRAINT `fk_usuario` FOREIGN KEY (`vendedor`) REFERENCES `usuarios` (`documento`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
