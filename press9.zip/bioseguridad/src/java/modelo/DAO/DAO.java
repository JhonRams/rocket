/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.DAO;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author JR
 */
public class DAO {

    private static conexion db = new conexion();

    public int select(Class clase, Object val[], int op) {
        String campo = "";
        String va = "";
        for (Field declaredField : clase.getDeclaredFields()) {
            campo += declaredField.getName() + ",";
            va += "?,";
        }
        String sql = "INSER INTO " + clase.getSimpleName() + " (" + campo + ") VALUES(" + va + ")";
        try {
            return db.ps(sql, val).executeUpdate();
        } catch (Exception ex) {
            System.out.println("Error En transaccion sql" + ex);
            return -1;
        }
    }

    public static int Insertar(Class clase, Object val[]) {

        try {
            String campo = "";
            String va = "";
            for (Field declaredField : clase.getDeclaredFields()) {
                campo += declaredField.getName() + ",";
                va += "?,";
            }
            String sql = "INSER INTO " + clase.getSimpleName() + " (" + campo + ") VALUES(" + va + ")";

            return db.ps(sql, val).executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error En transaccion sql" + ex);
            return -1;
        }
    }

    public static int Actualizar(Class clase, Object val[]) {
        try {
            String va = "";
            Field[] f = clase.getDeclaredFields();
            for (int i = 0; i < f.length - 1; i++) {
                va += "," + f[i].getName() + "=?";
            }
            String campo = f[f.length - 1].getName() + "=?";
            String sql = "UPDATE " + clase.getSimpleName() + " SET " + va.replaceFirst(",", "") + " WHERE " + campo;
            return db.ps(sql, val).executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error En transaccion sql" + ex);
            return -1;
        }
    }

    public static int Eliminar(Class clase, Object val[]) {
        try {
            Field[] f = clase.getDeclaredFields();
            String campo = f[f.length - 1].getName() + "=?";
            String sql = "DELETE FROM " + clase.getSimpleName() + " WHERE " + campo;
            return db.ps(sql, val).executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error En transaccion sql" + ex);
            return -1;
        }
    }

    public static Object datos(Object obj) {
        try {
            String sql = "SELECT * FROM privilegios WHERE id=?";
            Object val[] = {"1"};
            ResultSet rs = db.ps(sql, val).executeQuery(sql);
            ResultSetMetaData metadata = rs.getMetaData();
            rs.next();
            Class ob = obj.getClass();
            Object nuevo = ob.newInstance();
            Field[] s = ob.getDeclaredFields();
            Method[] d = ob.getMethods();
            for (int i = 1; i <= metadata.getColumnCount(); i++) {
                System.out.println(s[i - 1].getType().getSimpleName());
                s[i - 1].setAccessible(true);
                s[i - 1].set(nuevo, Tipo(s[i - 1].getType().getSimpleName(), rs, i));
            }
            return nuevo;
        } catch (SQLException ex) {
            System.out.println("error");
        } catch (InstantiationException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private static Object Tipo(String ty, ResultSet rs, int i) {
        try {
            switch (ty) {
                case "String":
                    return rs.getString(i);
                case "int":
                    return rs.getInt(i);
                default:
                    return null;
            }
        } catch (SQLException ex) {
            return null;
        }
    }
}
